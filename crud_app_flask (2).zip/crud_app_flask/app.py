from flask import Flask, request, jsonify, render_template, redirect, url_for, session
import mysql.connector
from werkzeug.security import generate_password_hash, check_password_hash
from functools import wraps

app = Flask(__name__)
app.config['SECRET_KEY'] = 'MY_KEY'

# Database Configuration
db_config = {
    "host": "localhost",
    "user": "root",
    "password": "Kritika@1997",
    "database": "EmployeeManagementSystem",
    "port": 3306
}

# Connect to database
def get_db_connection():
    connection = mysql.connector.connect(**db_config)
    return connection

from functools import wraps

def basic_auth_required(f):
    @wraps(f)  # Preserve the original function's metadata
    def wrapper(*args, **kwargs):
        if 'username' not in session or 'password' not in session:
            return jsonify({"message": "Missing or invalid Authorization header"}), 401

        username = session['username']
        password = session['password']

        connection = get_db_connection()
        cursor = connection.cursor(dictionary=True)
        try:
            cursor.execute("SELECT * FROM EmployerUser WHERE Email = %s", (username,))
            user = cursor.fetchone()
            if not user or not check_password_hash(user['Password'], password):
                return jsonify({"message": "Invalid username or password"}), 401
            request.user = {"id": user['Id'], "name": user['Name'], "role": user['RoleId']}
        except mysql.connector.Error as err:
            return jsonify({"message": "Database error"}), 500
        finally:
            cursor.close()
            connection.close()
        return f(*args, **kwargs)
    return wrapper


@app.route('/register', methods=['POST', 'GET'])
def register():
    if request.method == 'POST':
        name = request.form.get('name')
        email = request.form.get('email')
        password = request.form.get('password')
        confirm_password = request.form.get('confirm_password')
        role = request.form.get('role')
        manager_id = request.form.get('manager') if role == '2' else None

        if not name or not email or not password or not confirm_password or not role:
            return jsonify({"error": "All fields are required"}), 400
        if password != confirm_password:
            return jsonify({"error": "Passwords do not match"}), 400

        hashed_password = generate_password_hash(password)
        connection = get_db_connection()
        cursor = connection.cursor()
        try:
            cursor.execute(
                "INSERT INTO EmployerUser (Name, Email, Password, RoleId, ManagerId) VALUES (%s, %s, %s, %s, %s)",
                (name, email, hashed_password, role, manager_id)
            )
            connection.commit()
            return redirect(url_for('login'))
        except mysql.connector.Error as err:
            return jsonify({"error": f"Database error: {err}"}), 500
        finally:
            cursor.close()
            connection.close()

    connection = get_db_connection()
    cursor = connection.cursor(dictionary=True)
    try:
        cursor.execute("SELECT Id, Name FROM EmployerUser WHERE RoleId = 1")
        managers = cursor.fetchall()
    except mysql.connector.Error as err:
        managers = []
    finally:
        cursor.close()
        connection.close()
    return render_template('register.html', managers=managers)

@app.route('/login', methods=['POST', 'GET'])
def login():
    if request.method == 'POST':
        email = request.form.get('email')
        password = request.form.get('password')

        connection = get_db_connection()
        cursor = connection.cursor(dictionary=True)
        try:
            cursor.execute("SELECT * FROM EmployerUser WHERE Email = %s", (email,))
            user = cursor.fetchone()
            if not user or not check_password_hash(user['Password'], password):
                return jsonify({"error": "Invalid email or password"}), 401

            session['username'] = email
            session['password'] = password

            return redirect('/dashboard')
        except mysql.connector.Error as err:
            return jsonify({"error": f"Database error: {err}"}), 500
        finally:
            cursor.close()
            connection.close()

    return render_template('login.html')

@app.route('/employeelist')
@basic_auth_required
def employeelist():
    connection = get_db_connection()
    cursor = connection.cursor(dictionary=True)
    try:
        cursor.execute("SELECT * FROM EmployerUser")
        employees = cursor.fetchall()
        return render_template('employeelist.html', employees=employees)
    except mysql.connector.Error as err:
        return jsonify({"error": f"Database error: {err}"}), 500
    finally:
        cursor.close()
        connection.close()


@app.route('/dashboard')
@basic_auth_required
def dashboard():
    user_role = request.user['role']
    if user_role == 1:  # Manager
        return render_template('manager_dashboard.html')
    elif user_role == 2:  # Employee
        return render_template('employee_dashboard.html', employee=request.user)
    else:
        return jsonify({"error": "Invalid role"}), 401



@app.route('/manager-dashboard')
@basic_auth_required
def manager_dashboard():
    # Get manager's details from the database based on the logged-in manager's ID
    connection = get_db_connection()
    cursor = connection.cursor(dictionary=True)
    try:
        # Fetch the list of employees managed by the logged-in manager
        cursor.execute("SELECT * FROM EmployerUser WHERE ManagerId = %s", (request.user['id'],))
        employees = cursor.fetchall()
        print("Employees:", employees)  # Print the employees data
        if not employees:
            employees = []  # Ensure employees is an empty list if none found
        # Pass employees data to the template
        return render_template('manager_dashboard.html', employees=employees)
    except mysql.connector.Error as err:
        print("Error:", err)  # Print any errors
        return jsonify({"error": f"Database error: {err}"}), 500
    finally:
        cursor.close()
        connection.close()





@app.route('/view_comments/<int:employee_id>')
@basic_auth_required
def view_comments(employee_id):
    connection = get_db_connection()
    cursor = connection.cursor(dictionary=True)
    try:
        # Get all comments for the specific employee
        cursor.execute("SELECT * FROM EmployeeComments WHERE EmployeeUserId = %s", (employee_id,))
        comments = cursor.fetchall()
        return render_template('view_comments.html', comments=comments, employee_id=employee_id)
    except mysql.connector.Error as err:
        return jsonify({"error": f"Database error: {err}"}), 500
    finally:
        cursor.close()
        connection.close()

@app.route('/update_comment/<int:employee_id>', methods=['GET', 'POST'])
@basic_auth_required
def update_comment(employee_id):
    connection = get_db_connection()
    cursor = connection.cursor(dictionary=True)
    
    if request.method == 'POST':
        # Process comment update
        comment_text = request.form.get('comment_text')
        cursor.execute("UPDATE EmployeeComments SET CommentText = %s WHERE EmployeeUserId = %s AND AddedById = %s",
                       (comment_text, employee_id, request.user['id']))
        connection.commit()
        return redirect(url_for('manager_dashboard'))
    
    try:
        # Get the current comment of the employee if it exists
        cursor.execute("SELECT * FROM EmployeeComments WHERE EmployeeUserId = %s", (employee_id,))
        comment = cursor.fetchone()
        return render_template('update_comment.html', comment=comment, employee_id=employee_id)
    except mysql.connector.Error as err:
        return jsonify({"error": f"Database error: {err}"}), 500
    finally:
        cursor.close()
        connection.close()



# Route to display the employee list for a logged-in employee
@app.route('/employee_dashboard')
def employee_dashboard():
    if 'user_id' not in session:
        return redirect(url_for('login'))

    user_id = session['user_id']
    
    # Fetch the manager_id of the logged-in user
    connection = get_db_connection()
    cursor = connection.cursor(dictionary=True)
    
    cursor.execute("SELECT ManagerId FROM EmployerUser WHERE Id = %s", (user_id,))
    user_data = cursor.fetchone()
    manager_id = user_data['ManagerId'] if user_data else None
    
    if not manager_id:
        return "Error: Manager ID not found."
    
    # Fetch employees with the same ManagerId as the logged-in user
    cursor.execute("SELECT * FROM EmployerUser WHERE ManagerId = %s", (manager_id,))
    employees = cursor.fetchall()
    
    cursor.close()
    connection.close()
    
    return render_template('employee_dashboard.html', employees=employees)



@app.route('/logout')
def logout():
    session.pop('username', None)
    session.pop('password', None)
    return redirect(url_for('login'))

if __name__ == '__main__':
    app.run(debug=True)
