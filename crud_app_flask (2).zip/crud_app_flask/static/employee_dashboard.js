// Fetch employee data from backend
fetch('/api/employee-data')
    .then(response => response.json())
    .then(data => {
        const employee = data.employee;
        const comments = data.comments;

        // Update profile information section
        document.getElementById('profile-information').innerHTML = `
            <h2>Profile Information</h2>
            <p>Name: ${employee.name}</p>
            <p>Role: ${employee.role}</p>
            <p>Email: ${employee.email}</p>
        `;

        // Update comments section
        const commentsList = document.getElementById('comments');
        commentsList.innerHTML = '';
        comments.forEach(comment => {
            const commentHTML = `
                <li>
                    <p>${comment.comment_text}</p>
                    <p>Timestamp: ${comment.timestamp}</p>
                </li>
            `;
            commentsList.insertAdjacentHTML('beforeend', commentHTML);
        });
    })
    .catch(error => console.error('Error fetching employee data:', error));
