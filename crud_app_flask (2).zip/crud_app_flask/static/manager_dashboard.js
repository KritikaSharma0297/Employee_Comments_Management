const employeeListUl = document.getElementById('employee-list-ul');
const employeeCommentsSection = document.getElementById('employee-comments');
const commentsUl = document.getElementById('comments-ul');
const addCommentForm = document.getElementById('add-comment-form');
const addCommentBtn = document.getElementById('add-comment-btn');
const commentText = document.getElementById('comment-text');

employeeListUl.addEventListener('click', (e) => {
    if (e.target.classList.contains('employee-name')) {
        const employeeId = e.target.getAttribute('data-employee-id');
        const employeeName = e.target.textContent;
        document.getElementById('employee-name').textContent = employeeName;
        // Fetch comments for the selected employee
        fetch(`/comments/${employeeId}`)
            .then(response => response.json())
            .then(data => {
                commentsUl.innerHTML = '';
                data.forEach(comment => {
                    const commentLi = document.createElement('li');
                    commentLi.innerHTML = `
                        <p>${comment.comment_text}</p>
                        <p>Timestamp: ${comment.timestamp}</p>
                    `;
                    commentsUl.appendChild(commentLi);
                });
                employeeCommentsSection.style.display = 'block';
            })
            .catch(error => console.error(error));
    }
});

addCommentForm.addEventListener('submit', (e) => {
    e.preventDefault();
    const employeeId = employeeCommentsSection.querySelector('#employee-name').getAttribute('data-employee-id');
    const comment = commentText.value.trim();
    if (comment) {
        // Send a POST request to add the comment
        fetch('/add-comment', {
            method: 'POST',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            body: `employee_id=${employeeId}&comment_text=${comment}`
        })
            .then(response => response.json())
            .then(data => {
                if (data.error) {
                    console.error(data.error);
                } else {
                    commentText.value = '';
                    // Fetch updated comments for the selected employee
                    fetch(`/comments/${employeeId}`)
                        .then(response => response.json())
                        .then(data => {
                            commentsUl.innerHTML = '';
                            data.forEach(comment => {
                                const commentLi = document.createElement('li');
                                commentLi.innerHTML = `
                                    <p>${comment.comment_text}</p>
                                    <p>Timestamp: ${comment.timestamp}</p>
                                `;
                                commentsUl.appendChild(commentLi);
                            });
                        })
                        .catch(error => console.error(error));
                }
            })
            .catch(error => console.error(error));
    }
});
