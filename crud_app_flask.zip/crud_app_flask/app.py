from flask import Flask, url_for, render_template, request, redirect, jsonify
from flask import session
import mysql.connector
import jwt
import datetime
from werkzeug.security import generate_password_hash, check_password_hash



app = Flask(__name__)
app.config['SECRET_KEY'] = 'MY_KEY'
app.config['JWT_SECRET_KEY'] = 'JWT_SECRET_KEY'

# Configuration details to connect to our local database
db_config = {
    "host": "localhost",
    "user": "root",
    "password": "Kritika@1997",
    "database": "EmployeeManagementSystem",
    "port": 3306
}

# Connect to database
def get_db_connection():
    connection = mysql.connector.connect(**db_config)
    return connection

@app.route('/register', methods=["POST", "GET"])
def register():
    if request.method == 'POST':
        # Retrieve form data
        name = request.form.get('name')
        email = request.form.get('email')
        password = request.form.get('password')
        confirm_password = request.form.get('confirm_password')
        role = request.form.get('role')
        manager_id = request.form.get('manager') if role == '2' else None  # Only for employees

        # Validate required fields
        if not name or not email or not password or not confirm_password or not role:
            return jsonify({"error": "All fields are required"}), 400

        # Validate passwords match
        if password != confirm_password:
            return jsonify({"error": "Passwords do not match"}), 400

        # Hash the password
        hashed_password = generate_password_hash(password)

        # Insert user into database
        connection = get_db_connection()
        cursor = connection.cursor(dictionary=True)
        try:
            cursor.execute(
                "INSERT INTO EmployerUser (Name, Email, Password, RoleId, ManagerId) VALUES (%s, %s, %s, %s, %s)",
                (name, email, hashed_password, role, manager_id)
            )
            connection.commit()
            return redirect(url_for('login'))
        except mysql.connector.Error as err:
            return jsonify({"error": f"Database error: {err}"}), 500
        finally:
            cursor.close()
            connection.close()

    return render_template('register.html')


@app.route('/login', methods=["POST", "GET"])
def login():
    if request.method == 'POST':
        # Debugging: Log form data
        print("Form Data:", request.form)

        # Retrieve and validate form data
        email = request.form.get('email')
        password = request.form.get('password')

        if not email or not password:
            return jsonify({"error": "Email and Password are required"}), 400

        # Normalize email
        email = email.strip().lower()

        # Database connection
        connection = get_db_connection()
        cursor = connection.cursor(dictionary=True)
        try:
            # Query the database for the user by email
            cursor.execute("SELECT * FROM EmployerUser WHERE email = %s", (email,))
            user = cursor.fetchone()

            # Check if user exists
            if not user:
                return jsonify({"error": "User does not exist"}), 401

            # Verify the password
            if not password:
                return jsonify({"error": "Password is required"}), 400


            # Generate a JWT token
            token = jwt.encode({
                'user_id': user['Id'],
                'email': user['Email'],
                'exp': datetime.datetime.utcnow() + datetime.timedelta(hours=1)
            }, app.config['JWT_SECRET_KEY'], algorithm='HS256')

            # Return the token
            return jsonify({"token": token}), 200

        except mysql.connector.Error as err:
            return jsonify({"error": f"Database error: {err}"}), 500

        finally:
            cursor.close()
            connection.close()

    return render_template('login.html')



@app.route('/home')
def home():
    return render_template('dashboard.html')

@app.route('/dashboard')
def dashboard():
    return render_template('dashboard.html')

@app.route('/emplist')
def employeelist():
    return render_template('employeelist.html')

@app.route('/comments')
def comments():
    return render_template('comments.html')

@app.route('/reg')
def userregisteration():
    return render_template('userregisteration.html')

if __name__ == "__main__":
    app.run(debug=True)

