document.getElementById('login-form').addEventListener('submit', function (e) {
    e.preventDefault(); // Prevent the default form submission

    const email = document.getElementById('email').value;
    const password = document.getElementById('password').value;

    fetch('/login', {
        method: 'POST',
        body: new URLSearchParams({
            email: email,
            password: password,
        }),
    })
        .then(response => response.json())
        .then(data => {
            if (data.token) {
                // Store the token in localStorage
                localStorage.setItem('jwt_token', data.token);
                alert("Login successful!");
                window.location.href = "/dashboard"; // Redirect to a protected route
            } else {
                alert(data.error || "Login failed!");
            }
        })
        .catch(error => console.error("Error:", error));
});
